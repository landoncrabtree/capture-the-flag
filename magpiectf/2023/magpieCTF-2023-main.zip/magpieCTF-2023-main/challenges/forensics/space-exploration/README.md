# Space Exploration

### Category: Forensic Easy

### Author: Ned Liu 

## Description

Hello F-Team,

We've intercepted a suspicious image file from an OmniFlags channel known to discretely transport flags. See if you can find anything of value here.

Looking forward to your report, \
HQ

## Hints

1. The space is a little dark, can someone turn on the lights? (Don't over think it)


## Solution

1. Turn on the brightness of the image and you will see the flag in the upper left corner. This is an EASY challenge so DO NOT OVER THINK IT!

## Flag
magpie{wh0_7u2n3d_0ff_7h3_119h7}
