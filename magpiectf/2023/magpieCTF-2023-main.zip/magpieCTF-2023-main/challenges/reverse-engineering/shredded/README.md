# Shredded
### Category: Reverse Engineering
### Author: Delara (lara)

## Description

Hello R-Team,

We found a batch of what seems to be a shredded document in the dumpster behind Omniflags headquarters. Can you put the pieces back together and find what the document says?

HQ

## Hints

## Solution
1. You will need to reorder the pieces together until you get the original pdf document which is in the source folder
2. One you have the original document, you would notice that some letter are in bold
3. Putting the bolded letters together you will get the flag

## Flag
magpie{bestflagcompany}
