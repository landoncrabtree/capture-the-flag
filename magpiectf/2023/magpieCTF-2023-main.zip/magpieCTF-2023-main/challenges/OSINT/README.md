## OSINT

Open Source Intelligence (OSINT) challenges will be stored in separate folders here.